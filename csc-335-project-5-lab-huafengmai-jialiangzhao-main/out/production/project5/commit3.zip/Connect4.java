import javafx.application.Application;

public class Connect4 {
    /* the start main function, start the connect 4 game */
    public static void main(String[] args) {
        Application.launch(Connect4View.class, args);
    }
}
