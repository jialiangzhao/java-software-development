import java.util.ArrayList;
import java.util.Observable;
import java.util.stream.IntStream;

public class Connect4Model extends Observable {

    private final ArrayList<ArrayList<Integer>> boardList;
    private int play;

    public Connect4Model() {
        boardList = new ArrayList<>();
        for (int i = 0; i < 6; i++) {
            ArrayList<Integer> integers = new ArrayList<>();
            for (int j = 0; j < 7; j++) {
                integers.add(0);
            }
            boardList.add(integers);
        }
    }

    public void setPlay(int play) {
        this.play = play;
    }

    public ArrayList<ArrayList<Integer>> getBoardList() {
        return boardList;
    }

    public Connect4MoveMessage getMessage(int col) {
        return new Connect4MoveMessage(0, col, this.play);
    }

    public void moveTo(int place, int player) {
        int i = 5;
        while (i >= 0) {
            if (boardList.get(i).get(place) == 0) {
                boardList.get(i).set(place, player);
                break;
            }
            i--;
        }
        setChanged();
        notifyObservers(boardList);
    }

    public void moveTo(int place) {
        this.moveTo(place, play);
    }

    public boolean validMove(int col) {
        return boardList.get(0).get(col) == 0;
    }

    public boolean isFullCheck() {
        return isBoardFilled() || isWinner() != 0;
    }

    public boolean isBoardFilled() {
        return IntStream.range(0, 7).noneMatch(i -> boardList.get(0).get(i) == 0);
    }

    public int isWinner() {
        for (int row = 0; row < boardList.size(); row++) {
            for (int col = 0; col < boardList.get(row).size(); col++) {
                int currentPlay = boardList.get(row).get(col);
                if (currentPlay == 0) {
                    continue;
                }

                if (col + 3 < boardList.get(row).size() && currentPlay == boardList.get(row).get(col + 1) && currentPlay == boardList.get(row).get(col + 2) && currentPlay == boardList.get(row).get(col + 3)) {
                    return currentPlay;
                }
                if (row + 3 < boardList.size()) {
                    if (currentPlay == boardList.get(row + 1).get(col) && currentPlay == boardList.get(row + 2).get(col) && currentPlay == boardList.get(row + 3).get(col)) {
                        return currentPlay;
                    }
                    if (col + 3 < boardList.get(row).size() && currentPlay == boardList.get(row + 1).get(col + 1) && currentPlay == boardList.get(row + 2).get(col + 2) && currentPlay == boardList.get(row + 3).get(col + 3)) {
                        return currentPlay;
                    }
                    if (col - 3 >= 0 && currentPlay == boardList.get(row + 1).get(col - 1) && currentPlay == boardList.get(row + 2).get(col - 2) && currentPlay == boardList.get(row + 3).get(col - 3)) {
                        return currentPlay;
                    }
                }
            }
        }
        return 0;
    }

}
