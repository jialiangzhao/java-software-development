import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

class Connect4DialogBox extends Stage {

    /**
     * Holds the data to select if it is a server or client
     */
    private ToggleGroup createGroup;

    /**
     * Holds the port selected by the user; default 4000
     */
    private TextField portField;

    /**
     * Holds the data to select if the game is played by a human or computer
     */
    private ToggleGroup playAsGroup;

    /**
     * Holds the address of the server; default localhost
     */
    private TextField serverField;

    /**
     * This is the constructor of the dialog box used by the user to select options about the
     * game will be run. It creates the box and the shows it to the user when the user clicks new game
     */
    public Connect4DialogBox() {
        DialogPane dPane = new DialogPane();

        dPane.setMinHeight(130);
        dPane.setMinWidth(260);

        Alert dialog = new Alert(Alert.AlertType.NONE);
        dialog.initModality(Modality.APPLICATION_MODAL);
        dialog.initStyle(StageStyle.UTILITY);
        dialog.setTitle("Network Setup");

        createGroup = new ToggleGroup();

        RadioButton serverRadio = new RadioButton("Server");
        serverRadio.setSelected(true);
        serverRadio.setMinWidth(70);
        serverRadio.setToggleGroup(createGroup);

        RadioButton clientRadio = new RadioButton("Client");
        clientRadio.setMinWidth(70);
        clientRadio.setToggleGroup(createGroup);

        playAsGroup = new ToggleGroup();

        RadioButton humanRadio = new RadioButton("Human");
        humanRadio.setSelected(true);
        humanRadio.setMinWidth(70);
        humanRadio.setToggleGroup(playAsGroup);

        RadioButton computerRadio = new RadioButton("Computer");
        computerRadio.setMinWidth(80);
        computerRadio.setToggleGroup(playAsGroup);

        Text createText = new Text("   Create: ");
        Text playAsText = new Text("   Play as: ");
        Text serverText = new Text("   Server");
        Text portText = new Text("Port");

        serverField = new TextField("localhost");
        // default address = localhost
        serverField.setText("localhost");
        serverField.setMinWidth(90);

        portField = new TextField("4000");
        // default port = 4000
        portField.setText("4000");
        portField.setMinWidth(90);

        HBox createBox = new HBox(10);

        createBox.getChildren().addAll(createText, serverRadio, clientRadio);

        HBox playAsBox = new HBox(10);
        playAsBox.getChildren().addAll(playAsText, humanRadio, computerRadio);

        HBox serverPortBox = new HBox(10);
        serverPortBox.getChildren().addAll(serverText, serverField, portText, portField);

        VBox holder = new VBox(10);
        holder.getChildren().addAll(createBox, playAsBox, serverPortBox);


        dPane.getChildren().addAll(holder);
        dialog.setDialogPane(dPane);

        ButtonType ok = new ButtonType("OK");
        ButtonType cancel = new ButtonType("Cancel");
        dialog.getButtonTypes().addAll(ok, cancel);

        dialog.showAndWait();
    }

    /**
     * This method returns the port selected by the use. Default of 4000
     *
     * @return An int representing the port to run the game on
     */
    public int getPort() {
        return Integer.parseInt(portField.getText());
    }

    /**
     * This method returns the address of the server. default of localhost
     *
     * @return A string of the address of the server
     */
    public String getAddress() {
        return serverField.getText();

    }

    /**
     * This method returns a boolean indicating if the game is run by human or computer.
     * true = human, false = computer
     *
     * @return A boolean indicating how the game will be run (computer or human)
     */
    public boolean playAs() {
        if (this.playAsGroup.getSelectedToggle().toString().contains("Human")) {
            return true;
        }
        return false;
    }

    /**
     * This method returns a boolean indicating if the current instance is a server
     * or a client
     *
     * @return A boolean indicating if the instance is a server or client
     */
    public boolean createType() {
        if (this.createGroup.getSelectedToggle().toString().contains("Server")) {
            return false;
        }
        return true;
    }
}